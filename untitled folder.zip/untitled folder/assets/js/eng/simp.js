$(document).ready(function() {
	var floatrateradio = $('#floatrateradio'); // 

	// radio click event
	floatrateradio.on('click', function(e) {
		
		//loadCurrencyOne("false","");
		//loadCurrencyTwo();
		getEstimate('','');
	});

	var fixedrateradio = $('#fixedrateradio'); // 

	// radio click event
	fixedrateradio.on('click', function(e) {
		
		//loadCurrencyOne("true","");
		//loadCurrencyTwo();
		getEstimate('','');
	});

	var fromamount = $('#fromamount'); // 

	// radio click event
	fromamount.on('change', function(e) {
		
		//loadCurrencyOne("true","");
		//loadCurrencyTwo();
		getEstimate('','');
	});

	

});

let element;
let element2;
var genericExamples = document.querySelectorAll('[data-trigger]');
element = genericExamples[0];
element.choices = new Choices(element, {
  placeholderValue: 'This is a placeholder set in the config',
  searchPlaceholderValue: 'Search for Coin',
  allowHTML: 'True',
  position: 'bottom'
});		      
element2 = genericExamples[1];
element2.choices = new Choices(element2, {
  placeholderValue: 'This is a placeholder set in the config',
  searchPlaceholderValue: 'Search for Coin',
  allowHTML: 'True',
  position: 'bottom'
});

function loadCurrencyOne(floatfixed,exclude,select){
	// sending ajax request through jQuery

	var ccyholder1 = $('#ccyholder1');
	var ccy1img = $('#ccy1img');
	var ccyrefundimg = $('#ccyrefundimg');
	ccy1img.attr("src","assets/images/money.svg");
	ccyrefundimg.attr("src","assets/images/money.svg");
	$.ajax({
		url: 'simple.php?action=getcurrpairs&floatfixed='+floatfixed+'&exclude'+exclude+'&select='+select, // form action url
		type: 'GET', // form submit method get/post
		beforeSend: function() {
			
		},
		success: function(data) {
			element.choices.setChoices(async () => {
			  try {
			    const items = data;
			    return JSON.parse(items);
			  } catch (err) {
			    console.error(err);
			  }
			});
			//element.choices.init();
		      
			
		},
		error: function(e) {
			console.log(e)
		}
	});


}

function loadCurrencyTwo(excl,selected){
	// sending ajax request through jQuery
	var select = $('#choices-single-default'); // 
	var ccy1img = $('#ccy1img');
	var ccyrefundimg = $('#ccyrefundimg');
	var ccy2img = $('#ccy2img');
	var ccyfrom = $('#ccyfrom');
	if(excl!=""){
		var exclude=excl;
	}else{
		var excludee=select.val();
		var excludearr=excludee.split(";");
		var exclude=excludearr[0];
	}
	var toamount = $('#toamount');
	toamount.val('');
	ccyfrom.val('');
	
	if(exclude!=""){
		ccy1img.attr("src","https://static.simpleswap.io/images/currencies-logo/"+exclude+".svg");
		ccyrefundimg.attr("src","https://static.simpleswap.io/images/currencies-logo/"+exclude+".svg");
		ccyfrom.val(exclude);
		ccy2img.attr("src","assets/images/money.svg");
		loadCurrencyObj2(exclude);
		var floatrateradio = $('#floatrateradio').val();
		var floatfixed="true";
		if(floatrateradio=="on"){
			floatfixed="false";
		}
		var ccyholder2 = $('#ccyholder2');
		$.ajax({
			url: 'simple.php?action=getcurrpairs&floatfixed='+floatfixed+'&exclude='+exclude+'&select='+selected, // form action url
			type: 'GET', // form submit method get/post
			beforeSend: function() {
				
			},
			success: function(data) {
				//ccyholder2.html(data);

				element2.choices.destroy();
				element2.choices = new Choices(element2, {
				  placeholderValue: 'This is a placeholder set in the config',
				  searchPlaceholderValue: 'Search for Coin',
				  allowHTML: 'True',
				  position: 'bottom'
				});
				element2.choices.setChoices(async () => {
				  try {
				    const items = data;
				    return JSON.parse(items);
				  } catch (err) {
				    console.error(err);
				  }
				});			      
				
			},
			error: function(e) {
				console.log(e)
			}
		});
	}else{
		ccy1img.attr("src","assets/images/money.svg");
		
	}

}

function loadCurrencySecondImage(obj,excl){
	// sending ajax request through jQuery
	var select = $('#choices-single-default2'); // 
	var ccy2img = $('#ccy2img');
	var ccyto = $('#ccyto');
	if(excl!=="" && excl!==undefined){
		var exclude=excl;
	}else{
		var excludee=select.val();
		var excludearr=excludee.split(";");
		var exclude=excludearr[0];

	}
	ccyto.val('');
	var addressbox = $('#address');
	addressbox.val('');
	if(exclude!==""&& exclude!==undefined){
		ccyto.val(exclude);
		ccy2img.attr("src","https://static.simpleswap.io/images/currencies-logo/"+exclude+".svg");
		loadCurrencyObj(exclude);
		getEstimate(obj,exclude);
	}else{
		ccy2img.attr("src","assets/images/money.svg");
	}
	
}


function getEstimate(cfrom,cto){
	// sending ajax request through jQuery
	var select = $('#choices-single-default'); 
	if(cfrom!=""){
		var ccyfrom=cfrom;
	}else{
		var excludee=select.val();
		var excludearr=excludee.split(";");
		var ccyfrom=excludearr[0];
	}
	if(cto!=""){
		var ccyto=cto;
	}else{
		var select2 = $('#choices-single-default2'); 
		var excludee2=select2.val();
		var excludearr2=excludee2.split(";");
		var ccyto=excludearr2[0];
	}
	var radio = $("input[name='ratetype']:checked").val();
	var floatfixed="true";
	if(radio=="float"){
		floatfixed="false";
	}

	var fromamount = $('#fromamount');
	var fromamountval=fromamount.val();
	var toamount = $('#toamount');
	var estimateHelp = $('#estimateHelp');
	toamount.val('');
	toamount.attr("disabled","true");
	estimateHelp.html('');
	var buttonholder = $('#buttonholder');
	if(ccyfrom!=""&&ccyto!=""&&floatfixed!=""&&fromamountval!=""){
		buttonholder.html('<button class="btn btn-warning lh-1 btn-lg mb-4"" id="createbtn" type="button" disabled><span class="spinner-border spinner-border-sm" role="status"></span> Loading...</button>');
		toamount.attr("disabled","true");
		
		$.ajax({
			url: 'simple.php?action=getestimate&floatfixed='+floatfixed+'&ccyfrom='+ccyfrom+'&ccyto='+ccyto+'&amount='+fromamountval, // form action url
			type: 'GET', // form submit method get/post
			beforeSend: function() {
				
			},
			success: function(data) {
				//console.log('data',data);
				var rstarr=data.split(";");
				var rescode=rstarr[0];
				if(rescode=="0"){
					toamount.val(rstarr[1]);
					buttonholder.html('<button type="submit" name="create_ex" id="createbtn" class="btn btn-primary btn-lg mb-4">Exchange</button>');
					loadCurrencyObj(ccyto);
					valRecAddress();
				}else{
					estimateHelp.html(rstarr[1]);
					buttonholder.html('<button class="btn btn-warning lh-1 btn-lg mb-4"" type="button" disabled>'+rstarr[1]+'</button>');
					toamount.val('');
					loadCurrencyObj(ccyto);
					valRecAddress();
				}
				
			},
			error: function(e) {
				console.log(e);
				buttonholder.html('<button class="btn btn-warning lh-1 btn-lg mb-4"" id="createbtn" type="button" disabled>Network Error!</button>');
			}
		});
	}else{
		if(ccyto!==""){
			loadCurrencyObj(ccyto);
			valRecAddress();
		}
		toamount.val('');
		toamount.attr("disabled","true");
		
	}
}

function toggle(){
	var select1 = $('#choices-single-default'); 
	sel1=select1.val();
	var select2 = $('#choices-single-default2'); 
	sel2=select2.val();
	var addressbox = $('#address');
	var addressbox2 = $('#refundaddress');
	var ccyto = $('#ccyto');
	var ccyfrom = $('#ccyfrom');
	addressbox.val('');
	addressbox2.val('');
	if(sel1!==""&&sel2!==""){
		element.choices.setChoiceByValue(sel2);
		element2.choices.setChoiceByValue(sel1);
		var ccy1img = $('#ccy1img');
		var ccy2img = $('#ccy2img');
		ccyto.val(sel1);
		ccyfrom.val(sel2);
		var ccyrefundimg = $('#ccyrefundimg');
		ccy1img.attr("src","https://static.simpleswap.io/images/currencies-logo/"+sel2+".svg");
		ccy2img.attr("src","https://static.simpleswap.io/images/currencies-logo/"+sel1+".svg");
		ccyrefundimg.attr("src","https://static.simpleswap.io/images/currencies-logo/"+sel2+".svg");
		var fromamount = $('#fromamount'); 
		fromamountval=fromamount.val();
		
		getEstimate(sel2,sel1);
		loadCurrencyObj2(sel2);
		
	}
}

function loadCurrencyObj(obj){
	// sending ajax request through jQuery
	var addressbox = $('#address');
	var ccytoHelp = $('#ccytoHelp');
	ccytoHelp.html('');
	//addressbox.attr("src","assets/images/money.svg");
	$.ajax({
		url: 'simple.php?action=getcurrobj&ccy='+obj, // form action url
		type: 'GET', // form submit method get/post
		beforeSend: function() {
			
		},
		success: function(data) {
			data = JSON.parse(data);
			var wng=data['customProperties']['validation_address'];
			var ahlp=data['customProperties']['warnings_to'];
			addressbox.attr("pattern",wng);
			ccytoHelp.html(ahlp);
		      
			
		},
		error: function(e) {
			console.log(e)
		}
	});


}

function checkPattern(pat,valtocheck) {
    
    // Allow A-Z, a-z, 0-9 and underscore. Min 1 char.
   var outp=false;
   $.ajax({
		url: 'simple.php?action=valaddress&pat='+pat+'&addr='+valtocheck, // form action url
		type: 'GET', // form submit method get/post
		async: false,
		beforeSend: function() {
			
		},
		success: function(data) {
			if(data=="true"){
				outp = true;
			}else{
				outp = false;
			}
			
		      
			
		},
		error: function(e) {
			console.log(e)
		}
	});

	return outp;

}

function valRecAddress(){

	var addressbox = $('#address');
	var theaddress = addressbox.val();
	var addressHelp = $('#addressHelp');
	var oldhelp="";//addressHelp.html();
	var pat=addressbox.attr("pattern");
	var vali=addressbox.val();
	var select2 = $('#choices-single-default2'); 
	sel2=select2.val();
	var toamountval = $('#toamount').val();
	var createbtn = $('#createbtn');
	var isval=checkPattern(pat,theaddress);
	if(theaddress!==""){
		if(isval){
			addressHelp.html('');
			if(toamountval!==""){
				createbtn.attr("type","submit");
			}

		}else{
			createbtn.attr("type","button");
			addressHelp.html(oldhelp+" Invalid Address Format. Please check again!")
		}
	}
	//console.log("ispatval",isval);

}

function loadCurrencyObj2(obj){
	// sending ajax request through jQuery
	var addressbox = $('#refundaddress');
	var ccytoHelp = $('#refundaddressHelp');
	ccytoHelp.html('');
	//addressbox.attr("src","assets/images/money.svg");
	$.ajax({
		url: 'simple.php?action=getcurrobj&ccy='+obj, // form action url
		type: 'GET', // form submit method get/post
		beforeSend: function() {
			
		},
		success: function(data) {
			data = JSON.parse(data);
			var wng=data['customProperties']['validation_address'];
			var ahlp=data['customProperties']['warnings_to'];
			addressbox.attr("pattern",wng);
			ccytoHelp.html(ahlp);
		      
			
		},
		error: function(e) {
			console.log(e)
		}
	});


}


function valRecAddress2(){


	var toaddressval = $('#address').val();
	var addressbox = $('#refundaddress');
	var theaddress = addressbox.val();
	var addressHelp = $('#refundaddressHelp');
	var oldhelp="";//addressHelp.html();
	var pat=addressbox.attr("pattern");
	var vali=addressbox.val();
	var select2 = $('#choices-single-default'); 
	sel2=select2.val();
	var toamountval = $('#toamount').val();
	var createbtn = $('#createbtn');
	console.log("done",pat)
	var isval=checkPattern(pat,theaddress);
	if(theaddress!==""){
		if(isval){
			addressHelp.html('');
			
				valRecAddress();
			

		}else{
			createbtn.attr("type","button");
			addressHelp.html(oldhelp+" Invalid Address Format. Please check again!")
		}
	}else{
		createbtn.attr("type","submit");
	}
	//console.log("ispatval",isval);

}

