<?php
if(isset($_SESSION['notifys'])){
$alert=$_SESSION['notifys'];
?>
<script type="text/javascript">
	notifier.show('Well Done!', '<?php echo $alert; ?>', 'success', 'assets/images/notification/ok-48.png', 5000);
</script> 
<?php
$_SESSION['notifys']=null;
}

if(isset($_SESSION['notifye'])){
$alert=$_SESSION['notifye'];
?>
<script type="text/javascript">
	notifier.show('Ooops!', '<?php echo $alert; ?>', 'danger', 'assets/images/notification/high_priority-48.png', 5000);
</script> 
<?php
$_SESSION['notifye']=null;
}


?>

