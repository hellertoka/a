<?php require_once('../localhost.php');
require("mailersg.php");

if( isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) ){
	if (isset($_POST['topic']) AND trim($_POST['topic']) != "" AND isset($_POST['name']) AND trim($_POST['name']) != "" AND isset($_POST['email']) AND trim($_POST['email']) != "" AND isset($_POST['text']) AND trim($_POST['text']) != "") {
		$domain = $domain;
		$to = $adminemail;
		$topic = filter_var($_POST['topic'], FILTER_SANITIZE_STRING);
		$name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
		$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
		$message = filter_var($_POST['text'], FILTER_SANITIZE_STRING);
		$msg="Telephone: $topic<br>name: $name<br>email: $email<br>message: $message";
		$subj="New Contact Message";
		$sent = true;//emailset($domain, $to, $email, $name, $message, $topic);
		SendEmail($to,$subj, $msg);
		if ($sent) {
			echo '<div class="alert alert-success alert-dismissible" role="alert">Message sent! <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
		} else {
			echo '<div class="alert alert-danger alert-dismissible" role="alert">Couldn\'t send message! <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
		}
	}
	else {
		echo '<div class="alert alert-danger alert-dismissible" role="alert">All fields are required! <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
	}
	return;
}

function emailset($domain, $to, $from_mail, $from_name, $message2, $topic){
	$header = array();
	$header[] = "MIME-Version: 1.0";
	$header[] = "From: {$from_name}<{$from_mail}>";
	/* Set message content type HTML*/
	$header[] = "Content-type:text/html; charset=iso-8859-1";
	$header[] = "Content-Transfer-Encoding: 7bit";
	$subject = $topic;
	global $siteurl;
	
	$message ='<html><body><div style="padding:5px;background:#eae8e8;line-height:1.6;font-size:13px"><table width=100% border=0 style="background:#fff;padding:0 10px;max-width:500px;margin:0 auto;"><tr><td>';
	$message .= '<a href="'.$GLOBALS['siteurl'].'"><img style="width:240px;max-width:50%;margin:10px" src="'.$GLOBALS['siteurl'].'images/logo.png"/></a>';
	$message .= '</td></tr>';
	$message .='<tr><td colspan="2" style="border-top:1px solid #ccc;padding:10px 0"><h3 style="color:#333;font-weight:100;font-size:20px;margin:0;padding:0;font-family:Verdana,Arial,\'Segoe UI\',sans-serif;text-transform:capitalize">'.$topic.'</h3></td></tr>';
	$message .= '<tr><td colspan="2" style="color:#000;padding:10px 0">'.$message2.'</td></tr>';
	$message .= '<tr><td colspan="2" style="color:#999;font-size:12px;border-top:1px solid #ccc;padding:10px 0">From '.$from_name.'<br/><a href="mailto:'.$from_mail.'" target="_blank">Email back</a><br><br>This message was sent via '.$GLOBALS['domain'].' Contact portal.</td></tr></table></div></body></html>';
			SendEmail($to,$topic, $message);
return true;
}

?>