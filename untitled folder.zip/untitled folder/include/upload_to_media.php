<?php
require_once('../localhost.php');
include('functionsb.php');
  $accepted_origins = array($siteurl);
  
  /*defined settings - start*/
ini_set("memory_limit", "99M");
ini_set('post_max_size', '4M');
ini_set('max_execution_time', 600);
define('IMAGE_MEDIUM_DIR', '../uploads/media/');
define('IMAGE_MEDIUM_SIZE', 900);
/*defined settings - end*/
/*create directory with 777 permission if not exist - start*/
createDir(IMAGE_MEDIUM_DIR);


  reset ($_FILES);
  $temp = current($_FILES);
  if (is_uploaded_file($temp['tmp_name'])){
    if (isset($_SERVER['HTTP_ORIGIN'])) {
      // same-origin requests won't set an origin. If the origin is set, it must be valid.
      if (in_array($_SERVER['HTTP_ORIGIN'], $accepted_origins)) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
      } else {
        header("HTTP/1.0 403 Origin Denied");
        return;
      }
    }
    // Sanitize input
    if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
        header("HTTP/1.0 500 Invalid file name.");
        return;
    }
    // Verify extension
    if (!in_array(strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION)), array("gif", "jpg", "png"))) {
        header("HTTP/1.0 500 Invalid extension.");
        return;
    }
	
	$path[0] = $temp['tmp_name'];
	$file = pathinfo($temp['name']);
	$fileType = $temp["extension"];
	$desiredExt='png';
	$fileNameNew = mt_rand(333, 999) . time() . ".$desiredExt";
	$path[1] = IMAGE_MEDIUM_DIR . $fileNameNew;
	$pat='uploads/media/';
	$userid = $_SESSION['userid'];
	if (createbig($path[0], $path[1], $fileType, IMAGE_MEDIUM_SIZE, IMAGE_MEDIUM_SIZE,IMAGE_MEDIUM_SIZE)) {
			mysqli_query($localhost, "INSERT INTO photos (photo_name, photo_url, userid) VALUES ('$fileNameNew', '$pat$fileNameNew', '$userid')");
	}
	echo json_encode(array('location' => $siteurl.$pata.$fileNameNew));
    
  } else {
    // Notify editor that the upload failed
    header("HTTP/1.0 500 Server Error");
  }
?>