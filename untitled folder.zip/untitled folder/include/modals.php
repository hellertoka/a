<div id="exampleModalCenter" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">View Upload</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modalbody">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="modalCenter0" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Your profile photo</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col mb-3">
            <h6>It is not allowed to publish:</h6>
            <div class="progress">
            <div
              class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
              role="progressbar"
              style="width: 1%;"
              aria-valuenow="20"
              aria-valuemin="0"
              aria-valuemax="100"
              id="progressbar0"

            ></div>
          </div>
            <div class="demo-inline-spacing mt-3">
              <ol class="list-group list-group-numbered">
                <li class="list-group-item">photos of an explicitly sexual or pornographic nature</li>
                <li class="list-group-item">images aimed at inciting ethnic or racial hatred or aggression</li>
                <li class="list-group-item">photos involving persons under 18 years of age</li>
                <li class="list-group-item">third-party copyright protected photos</li>
                <li class="list-group-item">images larger than 5 MB and in a format other than JPG, GIF or PNG</li>
                <li class="list-group-item">Your face must be clearly visible on the photo.</li>
                <li class="list-group-item">All photos and videos uploaded by you must comply with these requirements, otherwise they can be removed.</li>
                <li class="list-group-item">Click on Close button below after successful upload</li>
              </ol>
            </div>
          </div>
        </div>
       
      </div>
      <form enctype="multipart/form-data" action="<?php echo $siteurl;?>image_profile_upload0.php" method="post" name="image_upload_form0" id="image_upload_form0">
        <div class="modal-footer">
         
          <a class="btn btn-primary" id="imgChange">
          <input type="hidden" name="user" value="<?php echo $userid; ?>">
          <input type="file" accept="image/*" name="image_upload_file0" id="image_upload_file0"><span id="donelabel0">Select a Photo</span></a>
          
           <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
            Close
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="modalCenter1" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">ID Front Photo</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col mb-3">
            <h6>It is not allowed to publish:</h6>
            <div class="progress">
            <div
              class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
              role="progressbar"
              style="width: 1%;"
              aria-valuenow="20"
              aria-valuemin="0"
              aria-valuemax="100"
              id="progressbar1"

            ></div>
          </div>
            <div class="demo-inline-spacing mt-3">
              <ol class="list-group list-group-numbered">
                <li class="list-group-item">photos of an explicitly sexual or pornographic nature</li>
                <li class="list-group-item">images aimed at inciting ethnic or racial hatred or aggression</li>
                <li class="list-group-item">photos involving persons under 18 years of age</li>
                <li class="list-group-item">third-party copyright protected photos</li>
                <li class="list-group-item">images larger than 5 MB and in a format other than JPG, GIF or PNG</li>
                <li class="list-group-item">Your face must be clearly visible on the photo.</li>
                <li class="list-group-item">All photos and videos uploaded by you must comply with these requirements, otherwise they can be removed.</li>
                <li class="list-group-item">Click on Close button below after successful upload</li>
              </ol>
            </div>
          </div>
        </div>
       
      </div>
      <form enctype="multipart/form-data" action="<?php echo $siteurl;?>image_profile_idfront_upload.php" method="post" name="image_upload_form" id="image_upload_form">
        <div class="modal-footer">
         
          <a class="btn btn-primary" id="imgChange">
          <input type="hidden" name="user" value="<?php echo $userid; ?>">
          <input type="file" accept="image/*" name="image_upload_file" id="image_upload_file"><span id="donelabel1">Select a Photo</span></a>
          
           <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
            Close
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="modalCenter2" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">ID Back Photo</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col mb-3">
            <h6>It is not allowed to publish:</h6>
            <div class="progress">
            <div
              class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
              role="progressbar"
              style="width: 1%;"
              aria-valuenow="20"
              aria-valuemin="0"
              aria-valuemax="100"
              id="progressbar2"

            ></div>
          </div>
            <div class="demo-inline-spacing mt-3">
              <ol class="list-group list-group-numbered">
                <li class="list-group-item">photos of an explicitly sexual or pornographic nature</li>
                <li class="list-group-item">images aimed at inciting ethnic or racial hatred or aggression</li>
                <li class="list-group-item">photos involving persons under 18 years of age</li>
                <li class="list-group-item">third-party copyright protected photos</li>
                <li class="list-group-item">images larger than 5 MB and in a format other than JPG, GIF or PNG</li>
                <li class="list-group-item">Your face must be clearly visible on the photo.</li>
                <li class="list-group-item">All photos and videos uploaded by you must comply with these requirements, otherwise they can be removed.</li>
                <li class="list-group-item">Click on Close button below after successful upload</li>
              </ol>
            </div>
          </div>
        </div>
       
      </div>
      <form enctype="multipart/form-data" action="<?php echo $siteurl;?>image_profile_idback_upload.php" method="post" name="image_upload_form2" id="image_upload_form2">
        <div class="modal-footer">
         
          <a class="btn btn-primary" id="imgChange">
          <input type="hidden" name="user" value="<?php echo $userid; ?>">
          <input type="file" accept="image/*" name="image_upload_file2" id="image_upload_file2"><span id="donelabel2">Select a Photo</span></a>
          
           <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
            Close
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="youTubeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <iframe height="350" src="https://www.youtube.com/embed/EngW7tLk6R8"></iframe>
    </div>
  </div>
</div>


<div class="modal fade" id="modalCenterProfit" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" id="modalbodydyn">
        
    </div>
  </div>
</div>