<?php
if(isset($_SESSION['success'])){
$alert=$_SESSION['success']
?>
<div class="alert alert-success alert-dismissible d-flex align-items-center fade show" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24">
    <use xlink:href="#check-circle-fill"></use>
  </svg>
  <div> <?php echo $alert; ?> </div>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>  
<?php
$_SESSION['success']=null;
}

if(isset($_SESSION['error'])){
$alert=$_SESSION['error']
?>
<div class="alert alert-danger alert-dismissible d-flex align-items-center fade show" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24">
    <use xlink:href="#exclamation-triangle-fill"></use>
  </svg>
  <div> <?php echo $alert; ?> </div>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
$_SESSION['error']=null;
}
?>