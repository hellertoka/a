<?php
require("sendgrid-php/sendgrid-php/sendgrid-php.php");

function SendEmail($to,$subject, $msg){

    $email = new \SendGrid\Mail\Mail(); 
    $email->setFrom("noreply@Chargebackbase.com", "Chargebackbase.com");
    $email->setSubject($subject);
    $email->addTo($to, "You");
    //$email->addContent("text/plain", "this is a notification");
    // $email->addContent(
    //     "text/html", ""
    // );
    $email->addContent("text/html", $msg);
    $sendgrid = new \SendGrid('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');
    try {
        $response = $sendgrid->send($email);
        //print $response->statusCode() . "\n";
        //print_r($response->headers());
        //print $response->body() . "\n";
    } catch (Exception $e) {
        echo 'Caught exception: '. $e->getMessage() ."\n";
    }
   
    //die();
    

}

function SendEmailBody($siteurl,$to,$subject,$msg){
    
    $domain=$siteurl;
    $message='<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <title>'.$subject.'</title> <style> /* Reset CSS */ body, h1, p { margin: 0; padding: 0; } body { font-family: Arial, sans-serif; background-color: #f6f6f6; } .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); } h1 { color: #333333; text-align: center; margin-bottom: 20px; } p { color: #666666; font-size: 16px; line-height: 1.5; margin-bottom: 20px; } .button { display: inline-block; padding: 10px 20px; background-color: #ff6b6b; color: #ffffff; text-decoration: none; border-radius: 5px; } .button:hover { background-color: #ff4f4f; } </style> </head> <body> <div class="container"> <h1>'.$domain.'</h1> <p>Hello there!</p> <p>'.$msg.'</p> <a href="'.$siteurl.'account" class="button">Login</a> </div> </body> </html>';

        SendEmail($to,$subject, $message);

}


?>